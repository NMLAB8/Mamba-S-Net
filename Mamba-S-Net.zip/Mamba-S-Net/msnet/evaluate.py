#!/usr/bin/env python3

import os
import time
import torch
import numpy as np
import soundfile as sf
import museval
import yaml
from ml_collections import ConfigDict
import argparse
from tqdm import tqdm
from pathlib import Path

from .MSNet import MSNet
from .inference import Seperator
from .log import logger


class MusicEvaluator:

    def __init__(self, model, checkpoint_path, config):
        self.separator = Seperator(model, checkpoint_path)
        self.config = config

        self.checkpoint = torch.load(checkpoint_path, map_location='cpu')
        self.epoch = self.checkpoint.get('epoch', 'unknown')

        self.instruments = self.separator.instruments

        logger.info(f"Evaluator initialized, model epoch: {self.epoch}")
        logger.info(f"Supported instruments: {self.instruments}")

    def calculate_bss_metrics(self, references_all, estimates_all):
        try:
            references_all = np.array(references_all)
            estimates_all = np.array(estimates_all)

            if references_all.ndim == 2:
                references_all = references_all[..., np.newaxis]
            if estimates_all.ndim == 2:
                estimates_all = estimates_all[..., np.newaxis]

            if references_all.shape[-1] > 1:
                references_all = np.mean(references_all, axis=-1, keepdims=True)
            if estimates_all.shape[-1] > 1:
                estimates_all = np.mean(estimates_all, axis=-1, keepdims=True)

            if np.all(np.abs(references_all) < 1e-10):
                logger.warning("Reference signal near zero")
                return 0.0, 0.0, 0.0, 0.0

            if np.all(np.abs(estimates_all) < 1e-10):
                logger.warning("Estimated signal near zero")
                return 0.0, 0.0, 0.0, 0.0

            min_length = min(references_all.shape[1], estimates_all.shape[1])
            references_all = references_all[:, :min_length, :]
            estimates_all = estimates_all[:, :min_length, :]

            eps = 1e-10
            references_all = references_all + eps * np.random.randn(*references_all.shape)
            estimates_all = estimates_all + eps * np.random.randn(*estimates_all.shape)

            for i in range(references_all.shape[0]):
                ref_max = np.max(np.abs(references_all[i])) + eps
                est_max = np.max(np.abs(estimates_all[i])) + eps
                references_all[i] = references_all[i] / ref_max
                estimates_all[i] = estimates_all[i] / est_max

            sdr, isr, sir, sar = museval.evaluate(references_all, estimates_all)

            def clean_metrics(metric_array, min_threshold=0.0):
                metric_array = np.array(metric_array)

                inf_nan_mask = np.isinf(metric_array) | np.isnan(metric_array)
                metric_array[inf_nan_mask] = min_threshold

                extreme_mask = metric_array < min_threshold
                metric_array[extreme_mask] = min_threshold

                return metric_array

            sdr_clean = clean_metrics(sdr)
            sir_clean = clean_metrics(sir)
            sar_clean = clean_metrics(sar)
            isr_clean = clean_metrics(isr)

            def calculate_overall_metric(metric_array):
                if len(metric_array.shape) == 2:
                    instrument_means = np.mean(metric_array, axis=1)
                    return float(np.mean(instrument_means))
                else:
                    return float(np.mean(metric_array))

            sdr_val = calculate_overall_metric(sdr_clean)
            sir_val = calculate_overall_metric(sir_clean)
            sar_val = calculate_overall_metric(sar_clean)
            isr_val = calculate_overall_metric(isr_clean)


            logger.debug(f"Original SDR shape: {sdr.shape}")
            logger.debug(f"SDR range before cleaning: [{np.min(sdr):.2f}, {np.max(sdr):.2f}]")
            logger.debug(f"SDR range after cleaning: [{np.min(sdr_clean):.2f}, {np.max(sdr_clean):.2f}]")
            logger.debug(f"Overall SDR: {sdr_val:.4f}")

            def validate_metric(value, metric_name=""):
                if value < -50 or value > 50:
                    logger.warning(f"{metric_name} value abnormal: {value:.2f} dB")
                return float(value)
            individual_metrics = {
                'sdr': [],
                'sir': [],
                'sar': [],
                'isr': []
            }


            metrics_arrays = {
                'sdr': sdr_clean,
                'sir': sir_clean,
                'sar': sar_clean,
                'isr': isr_clean
            }

            for metric_name, metric_array in metrics_arrays.items():
                if len(metric_array) > 0 and len(metric_array.shape) > 1:

                    for i in range(min(metric_array.shape[0], len(self.instruments))):
                        instrument_metric = float(np.mean(metric_array[i]))
                        validated_metric = validate_metric(instrument_metric, f"{metric_name}_{self.instruments[i]}")
                        individual_metrics[metric_name].append(validated_metric)


                    while len(individual_metrics[metric_name]) < len(self.instruments):
                        individual_metrics[metric_name].append(0.0)

                elif len(metric_array) > 0:

                    metric_flat = np.array(metric_array).flatten()
                    for i in range(min(len(metric_flat), len(self.instruments))):
                        individual_metric = float(metric_flat[i])
                        validated_metric = validate_metric(individual_metric, f"{metric_name}_{self.instruments[i]}")
                        individual_metrics[metric_name].append(validated_metric)


                    while len(individual_metrics[metric_name]) < len(self.instruments):
                        individual_metrics[metric_name].append(0.0)
                else:
                    individual_metrics[metric_name] = [0.0] * len(self.instruments)

            return (
                validate_metric(sdr_val, "Overall SDR"),
                validate_metric(sir_val, "Overall SIR"),
                validate_metric(sar_val, "Overall SAR"),
                validate_metric(isr_val, "Overall ISR"),
                individual_metrics
            )

        except Exception as e:
            logger.error(f"Error calculating BSS metrics: {str(e)}")
            import traceback
            logger.error(f"Detailed error info: {traceback.format_exc()}")
            individual_metrics = {
                'sdr': [0.0] * len(self.instruments),
                'sir': [0.0] * len(self.instruments),
                'sar': [0.0] * len(self.instruments),
                'isr': [0.0] * len(self.instruments)
            }
            return 0.0, 0.0, 0.0, 0.0, individual_metrics



    def load_audio_sources(self, mixture_path, source_paths):
        mixture_audio, rate = sf.read(mixture_path)


        source_audios = {}
        for name, path in source_paths.items():
            if os.path.exists(path):
                audio, sr = sf.read(path)
                assert sr == rate, f"Sample rate mismatch: {sr} != {rate}"
                source_audios[name] = audio
            else:
                logger.warning(f"Source file does not exist: {path}")

        return mixture_audio, source_audios, rate

    def calculate_metrics(self, references, estimates, sample_rate, rtf):
        metrics = {}

        try:

            sdr, sir, sar, isr, individual_metrics = self.calculate_bss_metrics(references, estimates)

            metrics['SDR'] = sdr
            metrics['SIR'] = sir
            metrics['SAR'] = sar
            metrics['ISR'] = isr
            metrics['RTF'] = rtf


            for i, instrument in enumerate(self.instruments):
                if i < len(individual_metrics['sdr']):
                    metrics[f'SDR_{instrument}'] = individual_metrics['sdr'][i]
                    metrics[f'SIR_{instrument}'] = individual_metrics['sir'][i]
                    metrics[f'SAR_{instrument}'] = individual_metrics['sar'][i]
                    metrics[f'ISR_{instrument}'] = individual_metrics['isr'][i]

            logger.debug(f"指标计算结果: SDR={sdr:.4f}, SIR={sir:.4f}, SAR={sar:.4f}, ISR={isr:.4f}")

        except Exception as e:
            logger.error(f"计算指标时出错: {e}")
            # 返回零值指标
            metrics = {
                'SDR': 0.0, 'SIR': 0.0, 'SAR': 0.0, 'ISR': 0.0, 'RTF': rtf
            }
            for instrument in self.instruments:
                metrics[f'SDR_{instrument}'] = 0.0
                metrics[f'SIR_{instrument}'] = 0.0
                metrics[f'SAR_{instrument}'] = 0.0
                metrics[f'ISR_{instrument}'] = 0.0

        return metrics

    def evaluate_folder(self, test_dir):
        all_metrics = {
            'SDR': [], 'SIR': [], 'SAR': [], 'ISR': [], 'RTF': []
        }


        for instrument in self.instruments:
            all_metrics[f'SDR_{instrument}'] = []
            all_metrics[f'SIR_{instrument}'] = []
            all_metrics[f'SAR_{instrument}'] = []
            all_metrics[f'ISR_{instrument}'] = []

        detailed_results = []


        sample_dirs = [d for d in os.listdir(test_dir)
                      if os.path.isdir(os.path.join(test_dir, d))]

        logger.info(f"Found {len(sample_dirs)} test samples")

        for sample_dir in tqdm(sample_dirs, desc="Evaluating samples"):
            sample_path = os.path.join(test_dir, sample_dir)


            mixture_path = os.path.join(sample_path, 'mixture.wav')
            source_paths = {}
            for instrument in self.instruments:
                source_paths[instrument] = os.path.join(sample_path, f'{instrument}.wav')

            try:

                mixture_audio, source_audios, sample_rate = self.load_audio_sources(
                    mixture_path, source_paths)

                if len(source_audios) != len(self.instruments):
                    logger.warning(f"Sample {sample_dir} missing source files, skipping")
                    continue

                start_time = time.time()

                estimates, _ = self.separator.separate_music_file(
                    mixture_audio, sample_rate)

                process_time = time.time() - start_time
                audio_length = len(mixture_audio) / sample_rate
                rtf = process_time / audio_length
                references = []
                estimated = []

                for instrument in self.instruments:
                    if instrument in source_audios and instrument in estimates:
                        references.append(source_audios[instrument])
                        estimated.append(estimates[instrument])
                    else:
                        logger.warning(f"Sample {sample_dir} missing {instrument} data")

                if len(references) != len(self.instruments):
                    logger.warning(f"Sample {sample_dir} data incomplete, skipping")
                    continue

                references = np.stack(references)
                estimated = np.stack(estimated)

                logger.debug(f"Reference signal shape: {references.shape}")
                logger.debug(f"Estimated signal shape: {estimated.shape}")

                metrics = self.calculate_metrics(references, estimated, sample_rate, rtf)

                for key in all_metrics:
                    if key in metrics:
                        all_metrics[key].append(metrics[key])

                sample_result = {'sample_name': sample_dir}
                sample_result.update(metrics)
                detailed_results.append(sample_result)

                logger.info(f"\nResults for sample {sample_dir}:")
                logger.info(f"SDR: {metrics['SDR']:.4f} dB")
                logger.info(f"SIR: {metrics['SIR']:.4f} dB")
                logger.info(f"SAR: {metrics['SAR']:.4f} dB")
                logger.info(f"ISR: {metrics['ISR']:.4f} dB")
                logger.info(f"RTF: {metrics['RTF']:.4f}")


                for instrument in self.instruments:
                    sdr_key = f'SDR_{instrument}'
                    sir_key = f'SIR_{instrument}'
                    sar_key = f'SAR_{instrument}'
                    isr_key = f'ISR_{instrument}'

                    if sdr_key in metrics:
                        logger.info(f"SDR_{instrument}: {metrics[sdr_key]:.4f} dB")
                    if sir_key in metrics:
                        logger.info(f"SIR_{instrument}: {metrics[sir_key]:.4f} dB")
                    if sar_key in metrics:
                        logger.info(f"SAR_{instrument}: {metrics[sar_key]:.4f} dB")
                    if isr_key in metrics:
                        logger.info(f"ISR_{instrument}: {metrics[isr_key]:.4f} dB")

            except Exception as e:
                logger.error(f"Error processing sample {sample_dir}: {e}")
                import traceback
                logger.error(f"Detailed error: {traceback.format_exc()}")
                continue
        final_metrics = {}
        for k, v in all_metrics.items():
            if len(v) > 0:
                final_metrics[k] = np.mean(v)
            else:
                final_metrics[k] = 0.0

        return final_metrics, detailed_results


def main():
    parser = argparse.ArgumentParser(description="MUSDB18 source separation evaluation")
    parser.add_argument('--test_dir', type=str, required=True,
                      help='Test data directory path')
    parser.add_argument('--config_path', type=str,
                      default='./conf/config.yaml',
                      help='Config file path')
    parser.add_argument('--checkpoint_path', type=str,
                      default='./result/checkpoint.th',
                      help='Model checkpoint path')
    parser.add_argument('--output_dir', type=str,
                      default='./evaluation_results',
                      help='Evaluation results save directory')
    args = parser.parse_args()


    os.makedirs(args.output_dir, exist_ok=True)


    with open(args.config_path, 'r') as f:
        config = ConfigDict(yaml.load(f, Loader=yaml.FullLoader))


    model = MSNet(**config.model)
    model.eval()

    if torch.cuda.is_available():
        device = torch.device('cuda')
        logger.info("Using GPU for evaluation")
    else:
        device = torch.device('cpu')
        logger.info("Using CPU for evaluation")

    model.to(device)

    evaluator = MusicEvaluator(model, args.checkpoint_path, config)

    logger.info("Starting MUSDB18 source separation evaluation...")
    metrics, detailed_results = evaluator.evaluate_folder(args.test_dir)

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    results_file = os.path.join(args.output_dir, f'quartet_evaluation_{timestamp}.txt')
    with open(results_file, 'w', encoding='utf-8') as f:
        f.write(f"=== Music Source Separation Evaluation Results (Epoch {evaluator.epoch}) ===\n\n")

        f.write("Evaluation Metrics:\n")
        f.write("- SDR (Signal-to-Distortion Ratio): Higher is better\n")
        f.write("- SIR (Signal-to-Interference Ratio): Higher is better\n")
        f.write("- SAR (Signal-to-Artifacts Ratio): Higher is better\n")
        f.write("- ISR (Image-to-Spatial distortion Ratio): Higher is better\n")

        f.write("- RTF (Real-Time Factor): Lower is better\n\n")

        f.write("=== Overall Average Results ===\n")
        for metric, value in metrics.items():
            if metric == 'RTF':
                f.write(f"{metric}: {value:.4f}\n")
            else:
                f.write(f"{metric}: {value:.4f} dB\n")

        f.write(f"\n=== 各乐器详细结果 ===\n")
        for instrument in evaluator.instruments:
            f.write(f"\n{instrument}:\n")
            sdr_key = f'SDR_{instrument}'
            sir_key = f'SIR_{instrument}'
            sar_key = f'SAR_{instrument}'
            isr_key = f'ISR_{instrument}'

            if sdr_key in metrics:
                f.write(f"  SDR: {metrics[sdr_key]:.4f} dB\n")
            if sir_key in metrics:
                f.write(f"  SIR: {metrics[sir_key]:.4f} dB\n")
            if sar_key in metrics:
                f.write(f"  SAR: {metrics[sar_key]:.4f} dB\n")
            if isr_key in metrics:
                f.write(f"  ISR: {metrics[isr_key]:.4f} dB\n")

        f.write(f"\n=== 详细样本结果 ===\n")
        for result in detailed_results:
            f.write(f"\n样本: {result['sample_name']}\n")
            f.write(f"SDR: {result['SDR']:.4f} dB\n")
            f.write(f"SIR: {result['SIR']:.4f} dB\n")
            f.write(f"SAR: {result['SAR']:.4f} dB\n")
            f.write(f"ISR: {result['ISR']:.4f} dB\n")
            f.write(f"RTF: {result['RTF']:.4f}\n")


            for instrument in evaluator.instruments:
                f.write(f"\n{instrument}:\n")
                sdr_key = f'SDR_{instrument}'
                sir_key = f'SIR_{instrument}'
                sar_key = f'SAR_{instrument}'
                isr_key = f'ISR_{instrument}'

                if sdr_key in result:
                    f.write(f"  SDR: {result[sdr_key]:.4f} dB\n")
                if sir_key in result:
                    f.write(f"  SIR: {result[sir_key]:.4f} dB\n")
                if sar_key in result:
                    f.write(f"  SAR: {result[sar_key]:.4f} dB\n")
                if isr_key in result:
                    f.write(f"  ISR: {result[isr_key]:.4f} dB\n")


    csv_file = os.path.join(args.output_dir, f'quartet_evaluation_{timestamp}.csv')
    with open(csv_file, 'w', encoding='utf-8') as f:

        headers = ['sample_name', 'SDR', 'SIR', 'SAR', 'ISR', 'RTF']
        for instrument in evaluator.instruments:
            headers.extend([
                f'SDR_{instrument}',
                f'SIR_{instrument}',
                f'SAR_{instrument}',
                f'ISR_{instrument}'
            ])
        f.write(','.join(headers) + '\n')


        for result in detailed_results:
            row = [
                result['sample_name'],
                f"{result['SDR']:.4f}",
                f"{result['SIR']:.4f}",
                f"{result['SAR']:.4f}",
                f"{result['ISR']:.4f}",
                f"{result['RTF']:.4f}"
            ]
            for instrument in evaluator.instruments:
                sdr_key = f'SDR_{instrument}'
                sir_key = f'SIR_{instrument}'
                sar_key = f'SAR_{instrument}'
                isr_key = f'ISR_{instrument}'


                for key in [sdr_key, sir_key, sar_key, isr_key]:
                    if key in result:
                        row.append(f"{result[key]:.4f}")
                    else:
                        row.append("0.0000")
            f.write(','.join(row) + '\n')

    logger.info(f"\nMusic source separation evaluation completed!")
    logger.info(f"Evaluation results saved to: {results_file}")
    logger.info(f"CSV results saved to: {csv_file}")
    logger.info(f"Total evaluated samples: {len(detailed_results)}")

    logger.info("\n=== Overall Evaluation Results ===")
    for metric, value in metrics.items():
        if metric == 'RTF':
            logger.info(f"{metric}: {value:.4f}")
        else:
            logger.info(f"{metric}: {value:.4f} dB")


if __name__ == "__main__":
    main()
